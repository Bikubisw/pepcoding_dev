function helperfn(){
    console.log(`List of all commands
    1. node mycli view <dirname> tree
    2. node mycli flat <dirname> flat
    3. node mycli organize <dirname>
    4. node mycli help
    `);
}
module.exports={
    helperfun:helperfn
}