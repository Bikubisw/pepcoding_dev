function organizefn(){
    console.log("organize fun ran");
}
module.exports={
    organizefun:organizefn
}