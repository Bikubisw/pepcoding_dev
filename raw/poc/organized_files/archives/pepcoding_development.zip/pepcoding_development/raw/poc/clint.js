let libfileobj=require("./lib.js");
console.log(libfileobj.a);
console.log(libfileobj.varname);
libfileobj.fn();
